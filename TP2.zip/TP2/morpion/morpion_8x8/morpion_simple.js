/* eslint-disable no-undef */
// Recuperation du canvas
// eslint-disable-next-line prefer-const
let c = document.getElementById('canvasMorpion')
// eslint-disable-next-line prefer-const
let ctx = c.getContext('2d')

// Recuperation tailles
// eslint-disable-next-line prefer-const
let largeur = c.width
// eslint-disable-next-line prefer-const
let hauteur = c.height

// Choix taille grille
// eslint-disable-next-line prefer-const
let nbColonnes = 8
// eslint-disable-next-line prefer-const
let nbLignes = 8

// Calcul taille cases
// eslint-disable-next-line prefer-const
let hauteurLigne = hauteur / nbLignes
// eslint-disable-next-line prefer-const
let largeurColonne = largeur / nbColonnes

// Choix aspect croix
// eslint-disable-next-line prefer-const
let ratioCroix = 0.7
// eslint-disable-next-line prefer-const
let epaisseurCroix = 1
// eslint-disable-next-line prefer-const
let couleurCroix = 'blue'

// Choix aspect rond
// eslint-disable-next-line prefer-const
let ratioRond = 0.7
// eslint-disable-next-line prefer-const
let epaisseurRond = 1
// eslint-disable-next-line prefer-const
let couleurRond = 'red'
let rayonRond = largeurColonne
if (largeurColonne > hauteurLigne) {
  rayonRond = hauteurLigne
}
rayonRond /= 2
rayonRond *= ratioRond

// score des joueurs 1 et 2
let scorePlayer1 = 0
let scorePlayer2 = 0

// nombres de parties jouées
let nbMatchesPlayed = 0

// Choix de la victoire
// eslint-disable-next-line prefer-const
let nbCoupsVictoire = 3

// Couleur de fond du canvas + contour
ctx.fillStyle = 'white'
ctx.strokeStyle = 'black'
ctx.fillRect(0, 0, largeur, hauteur)
ctx.strokeRect(0, 0, largeur, hauteur)

// Initialisation du jeu
let jeu = true
let joueurActuel = true
// eslint-disable-next-line prefer-const
let coups = []

// Creation de la grille lignes*colonnes
ctx.beginPath()
ctx.lineWidth = 1
ctx.strokeStyle = 'black'

// Creation de la grille physique

for (let i = 0; i < nbLignes - 1; i++) {
  // Creation ligne
  ctx.moveTo(0, (i + 1) * (hauteurLigne))
  ctx.lineTo(largeur, (i + 1) * (hauteurLigne))
  ctx.stroke()
}
// Creation colonne
for (let j = 0; j < nbColonnes - 1; j++) {
  // Creation case (colonne)
  ctx.moveTo((j + 1) * (largeurColonne), 0)
  ctx.lineTo((j + 1) * (largeurColonne), hauteur)
  ctx.stroke()
}

ctx.closePath()

// Evenement clic
c.addEventListener('click', play, false)

// Creation du tableau pour la grille
for (let i = 0; i < nbLignes; i++) {
  for (let j = 0; j < nbColonnes; j++) {
    coups.push([])
    coups[i].push(false)
  }
}

// Creation de croix
function createCroix (x, y) {
  // x,y est le centre de la croix
  ctx.beginPath()
  ctx.lineWidth = epaisseurCroix
  ctx.strokeStyle = couleurCroix
  ctx.moveTo(x - (largeurColonne / 2) * ratioCroix, y - (hauteurLigne / 2) * ratioCroix)
  ctx.lineTo(x + (largeurColonne / 2) * ratioCroix, y + (hauteurLigne / 2) * ratioCroix)

  ctx.moveTo(x + (largeurColonne / 2) * ratioCroix, y - (hauteurLigne / 2) * ratioCroix)
  ctx.lineTo(x - (largeurColonne / 2) * ratioCroix, y + (hauteurLigne / 2) * ratioCroix)

  ctx.stroke()
  ctx.closePath()
}

// Creation de rond
function createRond (x, y) {
  // x,y est le centre du rond
  ctx.beginPath()
  ctx.lineWidth = epaisseurRond
  ctx.strokeStyle = couleurRond
  ctx.arc(x, y, rayonRond, 0, 2 * Math.PI)
  ctx.stroke()
}

// Verification fin
function end () {
  for (let i = 0; i < nbLignes; i++) {
    for (let j = 0; j < nbColonnes; j++) {
      // eslint-disable-next-line eqeqeq
      if (coups[i][j] == false) {
        return false
      }
    }
  }
  return true
}

// Verification gagnant
// on va chercher a verifier si il y a N symboles identiques alignés
function gain (symbole, y, x) {
  let test = 0

  // Verification sur la meme ligne = sur le meme Y
  for (let i = 0; i < nbColonnes; i++) {
    // eslint-disable-next-line eqeqeq
    if (coups[y][i] == symbole) {
      test++
      if (test >= nbCoupsVictoire) {
        return true
      }
    } else {
      test = 0
    }
  }

  test = 0
  // Verification sur la meme colonne = sur le meme X
  for (let i = 0; i < nbLignes; i++) {
    // eslint-disable-next-line eqeqeq
    if (coups[i][x] == symbole) {
      test++
      if (test >= nbCoupsVictoire) {
        return true
      }
    } else {
      test = 0
    }
  }

  let x2 = x * 1
  let y2 = y * 1
  // Verification diagonale descendante
  while (x2 > 0 && y2 > 0) {
    x2--
    y2--
  }

  test = 0
  while (x2 < nbColonnes && y2 < nbLignes) {
    // eslint-disable-next-line eqeqeq
    if (coups[y2][x2] == symbole) {
      test++
      if (test >= nbCoupsVictoire) {
        return true
      }
    } else {
      test = 0
    }
    x2++
    y2++
  }

  x2 = x * 1
  y2 = y * 1
  // Verification diagonale asscendante
  while (x2 < nbColonnes - 1 && y2 > 0) {
    x2++
    y2--
  }

  test = 0
  while (x2 >= 0 && y2 < nbLignes) {
    // eslint-disable-next-line eqeqeq
    if (coups[y2][x2] == symbole) {
      test++
      if (test >= nbCoupsVictoire) {
        return true
      }
    } else {
      test = 0
    }
    x2--
    y2++
  }

  return false
}

// Lorsqu'on clique
function play (event) {
  // eslint-disable-next-line no-undef
  x = event.clientX - c.offsetLeft
  // eslint-disable-next-line no-undef
  y = event.clientY - c.offsetTop + document.documentElement.scrollTop

  // eslint-disable-next-line no-undef
  // eslint-disable-next-line prefer-const
  let caseX = parseInt(x / (largeur / nbColonnes))
  // eslint-disable-next-line no-undef
  // eslint-disable-next-line prefer-const
  let caseY = parseInt(y / (hauteur / nbLignes))

  // eslint-disable-next-line prefer-const
  let milieuX = caseX * largeurColonne + largeurColonne / 2
  // eslint-disable-next-line prefer-const
  let milieuY = caseY * hauteurLigne + hauteurLigne / 2

  // Si jeu en route
  if (jeu) {
    if (!coups[caseY][caseX]) {
      if (joueurActuel) {
        createRond(milieuX, milieuY)
        coups[caseY][caseX] = 'rond'
        temp = 'rond'
        document.getElementById('joueur').innerHTML = 'Au joueur 2 de placer une croix'
      } else {
        createCroix(milieuX, milieuY)
        coups[caseY][caseX] = 'croix'
        temp = 'croix'
        document.getElementById('joueur').innerHTML = 'Au joueur 1 de placer un rond'
      }

      joueurActuel = !joueurActuel

      if (gain(temp, caseY, caseX)) {
        if (joueurActuel) {
          document.getElementById('joueur').innerHTML = 'Victoire pour le joueur 2 !'
          document.getElementById('nbMatches').innerHTML = ++nbMatchesPlayed + ' manche'
          if (nbMatchesPlayed >= 2) {
            document.getElementById('nbMatches').innerHTML = ++nbMatchesPlayed + ' manches'
          }
          document.getElementById('score2').innerHTML = 'Joueur 2 : ' + ++scorePlayer2
          jeu = false
        } else {
          document.getElementById('joueur').innerHTML = 'Victoire pour le joueur 1 !'
          document.getElementById('nbMatches').innerHTML = ++nbMatchesPlayed + ' manche'
          if (nbMatchesPlayed >= 2) {
            document.getElementById('nbMatches').innerHTML = ++nbMatchesPlayed + ' manches'
          }
          document.getElementById('score1').innerHTML = 'Joueur 1 : ' + ++scorePlayer1
          jeu = false
        }
      } else {
        if (end()) {
          jeu = false
          document.getElementById('joueur').innerHTML = "Terminé. Personne n'a gagné."
          document.getElementById('nbMatches').innerHTML = ++nbMatchesPlayed + ' manche'
          if (nbMatchesPlayed >= 2) {
            document.getElementById('nbMatches').innerHTML = ++nbMatchesPlayed + ' manches'
          }
        }
      }
    }
  }
  // eslint-disable-next-line no-unused-vars
  function newMatch () {

  }
}
