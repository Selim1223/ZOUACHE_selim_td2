const article0 = document.createElement('h2')
article0.textContent = 'Article 0 - Règle'

const article1 = document.body.childNodes[1]

const p0 = document.createElement('p')
p0.textContent = 'Il est interdit de vous doubler, sous peine de disqualification.'

document.body.insertBefore(p0, article1)
document.body.insertBefore(article0, p0)

const allH2 = document.getElementsByTagName('h2')
// eslint-disable-next-line no-undef
for (i = 0; i < allH2.length; i++) {
  // eslint-disable-next-line no-undef
  allH2[i].innerHTML = allH2[i].innerHTML.toUpperCase()
}
// eslint-disable-next-line no-undef
for (i = 0; i < allH2.length; i++) {
// eslint-disable-next-line no-undef
  const numArticle = allH2[i].innerHTML.slice(8, 10)
  // eslint-disable-next-line no-undef
  allH2[i].innerHTML = allH2[i].innerHTML.replace(numArticle, i + 1)
}

const body = document.getElementsByTagName('body')
const balises = []
for (let i = 0; i < body[0].children.length; i++) {
  balises[i] = body[0].children[i].tagName
}

let counter = 0
// eslint-disable-next-line no-undef
for (i = 0; i < balises.length; i++) {
// eslint-disable-next-line no-undef
  if (balises[i] === 'H2') {
    counter++
  }
  if (counter % 2 === 0) {
    // eslint-disable-next-line no-undef
    body[0].children[i].style.backgroundColor = '#C0C0C0'
  }
}
